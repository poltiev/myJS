A Pen created at CodePen.io. You can find this one at https://codepen.io/noeldelgado/pen/pGwFx.

 After seeing this site http://fitzfitzpatrick.com/ I decided to give a try to the  "direction-aware hover effect". My first thought was to do it with a pure CSS, not too late I changed my mind and decided to use JS (I need to sleep anyway).

It's kind of simple, using JS we can easily detect the direction the cursor is coming, then, I am using CSS animations for each case (8 in total).